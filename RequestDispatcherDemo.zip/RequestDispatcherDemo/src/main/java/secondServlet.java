import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class secondServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)
{
try
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
pw.println("this is second servlet");
String s=req.getParameter("t1");
String t=req.getParameter("t2");
pw.println("the user name is "+s);
pw.println("the password is "+t);
}
catch(Exception ae)
{
ae.printStackTrace();
}
}
}