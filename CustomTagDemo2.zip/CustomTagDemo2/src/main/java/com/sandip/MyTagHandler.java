package com.sandip;  
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;  
public class MyTagHandler extends TagSupport
{  
	public int doStartTag() throws JspException 
	{
		try
		{
		JspWriter out =pageContext.getOut();
		out.print("<marquee><font color=red><b>Mphasis Chandragupta Employees</b></font></marquee>");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return SKIP_BODY;//will not evaluate the body content of the tag  
	}  
}  