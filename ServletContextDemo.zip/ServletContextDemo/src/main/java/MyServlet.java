import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
   
  private String dbName="";
  private String dbPassword="";

  public void init(ServletConfig config) throws ServletException  {
	  super.init(config);
	  ServletContext context = getServletContext();
	  dbName = context.getInitParameter("name");
	  dbPassword = context.getInitParameter("password");
  }

  public void doGet (HttpServletRequest req, HttpServletResponse res) throws IOException
  {
    ServletOutputStream out = res.getOutputStream();
    res.setContentType("text/html");
    out.println("<html><head><title>Basic Servlet</title></head>");
    out.println("<body>Database username is  <b>" + dbName);
    out.println("</b><br>Database password is  <b>" + dbPassword + "</b>");
    out.println("</body></html>");
  }
}