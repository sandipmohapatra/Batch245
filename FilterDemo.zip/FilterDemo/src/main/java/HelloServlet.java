import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpServlet;
public class HelloServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<h3>welcome to servlet</h3>");
	}
}
