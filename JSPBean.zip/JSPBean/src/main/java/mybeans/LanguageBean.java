package mybeans;
public class LanguageBean
{
	private String name;
	private String language;
	
	public LanguageBean(){}
	
	public void setName(String name)  //assigning
	{
		this.name=name;
	}
	
	public String getName()//for method call
	{
		return name;
	}
	
	public void setLanguage(String language)
	{
		this.language=language;
	}
	
	public String getLanguage()
	{
		return language;
	}
	
	
public String getLanguageComments()
	{
		if(language.equals("Java"))
		{
			return "Java is a Object Oriented Language";
		}
		else if(language.equals("C++"))
		{
			return "C++ is a Basic Language";
		}
		else if(language.equals("Perl"))
		{
			return "Perl is a scripting Language";
		}
		else
		{
			return "No Language";
		}
	}
}