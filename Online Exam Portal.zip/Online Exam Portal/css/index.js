const questions = [
  {
    question: "What is CSS?",
    optionA: "CSS is a style sheet language.",
    optionB:
      "CSS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC: "All of the mentioned",
    optionD: "CSS is the language used to style the HTML documents.",
    correctOption: "optionC",
  },

  {
    question: "Which of the following tag is used to embed css in html page?",
    optionA: "div",
    optionB: "css",
    optionC: "style",
    optionD: "script",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS selectors are used to specify a group of elements ?",
    optionA: "class and tag",
    optionB: "tag",
    optionC: "id",
    optionD: "class",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following has introduced text, list, box, margin, border, color, and background properties?",
    optionA: "HTML",
    optionB: "PHP",
    optionC: "CSS",
    optionD: "Ajax",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS framework is used to create a responsive design? ",
    optionA: "CSS",
    optionB: "javascript",
    optionC: "django",
    optionD: "bootstrap",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS style property is used to specify an italic text?",
    optionA: "font family",
    optionB: "style",
    optionC: "size",
    optionD: "background color",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is not the property of the CSS box model?",
    optionA: "margin",
    optionB: "width",
    optionC: "color",
    optionD: "height",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS Property controls how an element is positioned?",
    optionA: "position",
    optionB: "static",
    optionC: "fix",
    optionD: "set",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following CSS Property sets the stacking order of positioned elements?",

    optionA: "y index",
    optionB: "x index",
    optionC: "all of these",
    optionD: "z index",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS property defines the space between cells in a table?",
    optionA: "border size",
    optionB: "border",
    optionC: "none",
    optionD: "border spacing",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following property allows a marquee to be used in the case of a text-overflow?",
    optionA: "style",
    optionB: "text",
    optionC: "all",
    optionD: "marquee",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is an appropriate value for the overflow element?",
    optionA: "scroll",
    optionB: "all",
    optionC: "hidden",
    optionD: "/auto",
    correctOption: "optionB",
  },
  {
    question: "What is CSS?",
    optionA: "CSS is a style sheet language.",
    optionB:
      "CSS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC: "All of the mentioned",
    optionD: "CSS is the language used to style the HTML documents.",
    correctOption: "optionC",
  },

  {
    question: "Which of the following tag is used to embed css in html page?",
    optionA: "div",
    optionB: "css",
    optionC: "style",
    optionD: "script",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS selectors are used to specify a group of elements ?",
    optionA: "class and tag",
    optionB: "tag",
    optionC: "id",
    optionD: "class",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following has introduced text, list, box, margin, border, color, and background properties?",
    optionA: "HTML",
    optionB: "PHP",
    optionC: "CSS",
    optionD: "Ajax",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS framework is used to create a responsive design? ",
    optionA: "CSS",
    optionB: "javascript",
    optionC: "django",
    optionD: "bootstrap",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS style property is used to specify an italic text?",
    optionA: "font family",
    optionB: "style",
    optionC: "size",
    optionD: "background color",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is not the property of the CSS box model?",
    optionA: "margin",
    optionB: "width",
    optionC: "color",
    optionD: "height",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS Property controls how an element is positioned?",
    optionA: "position",
    optionB: "static",
    optionC: "fix",
    optionD: "set",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following CSS Property sets the stacking order of positioned elements?",

    optionA: "y index",
    optionB: "x index",
    optionC: "all of these",
    optionD: "z index",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS property defines the space between cells in a table?",
    optionA: "border size",
    optionB: "border",
    optionC: "none",
    optionD: "border spacing",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following property allows a marquee to be used in the case of a text-overflow?",
    optionA: "style",
    optionB: "text",
    optionC: "all",
    optionD: "marquee",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is an appropriate value for the overflow element?",
    optionA: "scroll",
    optionB: "all",
    optionC: "hidden",
    optionD: "/auto",
    correctOption: "optionB",
  },
  {
    question: "What is CSS?",
    optionA: "CSS is a style sheet language.",
    optionB:
      "CSS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC: "All of the mentioned",
    optionD: "CSS is the language used to style the HTML documents.",
    correctOption: "optionC",
  },

  {
    question: "Which of the following tag is used to embed css in html page?",
    optionA: "div",
    optionB: "css",
    optionC: "style",
    optionD: "script",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS selectors are used to specify a group of elements ?",
    optionA: "class and tag",
    optionB: "tag",
    optionC: "id",
    optionD: "class",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following has introduced text, list, box, margin, border, color, and background properties?",
    optionA: "HTML",
    optionB: "PHP",
    optionC: "CSS",
    optionD: "Ajax",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS framework is used to create a responsive design? ",
    optionA: "CSS",
    optionB: "javascript",
    optionC: "django",
    optionD: "bootstrap",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS style property is used to specify an italic text?",
    optionA: "font family",
    optionB: "style",
    optionC: "size",
    optionD: "background color",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is not the property of the CSS box model?",
    optionA: "margin",
    optionB: "width",
    optionC: "color",
    optionD: "height",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS Property controls how an element is positioned?",
    optionA: "position",
    optionB: "static",
    optionC: "fix",
    optionD: "set",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following CSS Property sets the stacking order of positioned elements?",

    optionA: "y index",
    optionB: "x index",
    optionC: "all of these",
    optionD: "z index",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS property defines the space between cells in a table?",
    optionA: "border size",
    optionB: "border",
    optionC: "none",
    optionD: "border spacing",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following property allows a marquee to be used in the case of a text-overflow?",
    optionA: "style",
    optionB: "text",
    optionC: "all",
    optionD: "marquee",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is an appropriate value for the overflow element?",
    optionA: "scroll",
    optionB: "all",
    optionC: "hidden",
    optionD: "/auto",
    correctOption: "optionB",
  },
  {
    question: "What is CSS?",
    optionA: "CSS is a style sheet language.",
    optionB:
      "CSS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC: "All of the mentioned",
    optionD: "CSS is the language used to style the HTML documents.",
    correctOption: "optionC",
  },

  {
    question: "Which of the following tag is used to embed css in html page?",
    optionA: "div",
    optionB: "css",
    optionC: "style",
    optionD: "script",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS selectors are used to specify a group of elements ?",
    optionA: "class and tag",
    optionB: "tag",
    optionC: "id",
    optionD: "class",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following has introduced text, list, box, margin, border, color, and background properties?",
    optionA: "HTML",
    optionB: "PHP",
    optionC: "CSS",
    optionD: "Ajax",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS framework is used to create a responsive design? ",
    optionA: "CSS",
    optionB: "javascript",
    optionC: "django",
    optionD: "bootstrap",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS style property is used to specify an italic text?",
    optionA: "font family",
    optionB: "style",
    optionC: "size",
    optionD: "background color",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is not the property of the CSS box model?",
    optionA: "margin",
    optionB: "width",
    optionC: "color",
    optionD: "height",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following CSS Property controls how an element is positioned?",
    optionA: "position",
    optionB: "static",
    optionC: "fix",
    optionD: "set",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following CSS Property sets the stacking order of positioned elements?",

    optionA: "y index",
    optionB: "x index",
    optionC: "all of these",
    optionD: "z index",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following CSS property defines the space between cells in a table?",
    optionA: "border size",
    optionB: "border",
    optionC: "none",
    optionD: "border spacing",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following property allows a marquee to be used in the case of a text-overflow?",
    optionA: "style",
    optionB: "text",
    optionC: "all",
    optionD: "marquee",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following is an appropriate value for the overflow element?",
    optionA: "scroll",
    optionB: "all",
    optionC: "hidden",
    optionD: "/auto",
    correctOption: "optionB",
  },
];
