const questions = [
  {
    question: "What does HTML stand for?",
    optionA: "Hypertext Machine language.",
    optionB: "Hypertext and links markup language.",
    optionC: "Hypertext Markup Language.",
    optionD: "Hightext machine language.",
    correctOption: "optionC",
  },

  {
    question: "How is document type initialized in HTML5.?",
    optionA: "/DOCTYPE HTML",
    optionB: "/DOCTYPE",
    optionC: "!DOCTYPE HTML",
    optionD: "/DOCTYPE html",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following HTML Elements is used for making any text bold ?",
    optionA: "p",
    optionB: "i",
    optionC: "li",
    optionD: "b",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following HTML element is used for creating an unordered list?",
    optionA: "ui",
    optionB: "i",
    optionC: "ul",
    optionD: "em",
    correctOption: "optionC",
  },

  {
    question: "Which of the following characters indicate closing of a tag? ",
    optionA: "dot",
    optionB: "double slash",
    optionC: "double dot",
    optionD: "slash",
    correctOption: "optionD",
  },

  {
    question: "What is the font-size of the h1 heading tag?",
    optionA: "2 em",
    optionB: "5 em",
    optionC: "1.5 em",
    optionD: "3 em",
    correctOption: "optionA",
  },

  {
    question: "How many attributes are there in HTML5?",
    optionA: "one",
    optionB: "Four",
    optionC: "None of these",
    optionD: "Two",
    correctOption: "optionC",
  },

  {
    question: "How many heading tags are there in HTML5?",
    optionA: "6",
    optionB: "8",
    optionC: "12",
    optionD: "9",
    correctOption: "optionA",
  },

  {
    question: "Which of these numbers is an odd number ?",
    optionA: "Ten",
    optionB: "Twelve",
    optionC: "Eight",
    optionD: "Eleven",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following attributes is used to add link to any element?",
    optionA: "ref",
    optionB: "link",
    optionC: "new ref",
    optionD: "href",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "i",
    optionB: "italic",
    optionC: "style='i'",
    optionD: "style='italic'",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "/br",
    optionB: "br",
    optionC: "break",
    optionD: "/break",
    correctOption: "optionB",
  },
  {
    question: "What does HTML stand for?",
    optionA: "Hypertext Machine language.",
    optionB: "Hypertext and links markup language.",
    optionC: "Hypertext Markup Language.",
    optionD: "Hightext machine language.",
    correctOption: "optionC",
  },

  {
    question: "How is document type initialized in HTML5.?",
    optionA: "/DOCTYPE HTML",
    optionB: "/DOCTYPE",
    optionC: "!DOCTYPE HTML",
    optionD: "/DOCTYPE html",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following HTML Elements is used for making any text bold ?",
    optionA: "p",
    optionB: "i",
    optionC: "li",
    optionD: "b",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following HTML element is used for creating an unordered list?",
    optionA: "ui",
    optionB: "i",
    optionC: "ul",
    optionD: "em",
    correctOption: "optionC",
  },

  {
    question: "Which of the following characters indicate closing of a tag? ",
    optionA: "dot",
    optionB: "double slash",
    optionC: "double dot",
    optionD: "slash",
    correctOption: "optionD",
  },

  {
    question: "What is the font-size of the h1 heading tag?",
    optionA: "2 em",
    optionB: "5 em",
    optionC: "1.5 em",
    optionD: "3 em",
    correctOption: "optionA",
  },

  {
    question: "How many attributes are there in HTML5?",
    optionA: "one",
    optionB: "Four",
    optionC: "None of these",
    optionD: "Two",
    correctOption: "optionC",
  },

  {
    question: "How many heading tags are there in HTML5?",
    optionA: "6",
    optionB: "8",
    optionC: "12",
    optionD: "9",
    correctOption: "optionA",
  },

  {
    question: "Which of these numbers is an odd number ?",
    optionA: "Ten",
    optionB: "Twelve",
    optionC: "Eight",
    optionD: "Eleven",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following attributes is used to add link to any element?",
    optionA: "ref",
    optionB: "link",
    optionC: "new ref",
    optionD: "href",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "i",
    optionB: "italic",
    optionC: "style='i'",
    optionD: "style='italic'",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "/br",
    optionB: "br",
    optionC: "break",
    optionD: "/break",
    correctOption: "optionB",
  },
  {
    question: "What does HTML stand for?",
    optionA: "Hypertext Machine language.",
    optionB: "Hypertext and links markup language.",
    optionC: "Hypertext Markup Language.",
    optionD: "Hightext machine language.",
    correctOption: "optionC",
  },

  {
    question: "How is document type initialized in HTML5.?",
    optionA: "/DOCTYPE HTML",
    optionB: "/DOCTYPE",
    optionC: "!DOCTYPE HTML",
    optionD: "/DOCTYPE html",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following HTML Elements is used for making any text bold ?",
    optionA: "p",
    optionB: "i",
    optionC: "li",
    optionD: "b",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following HTML element is used for creating an unordered list?",
    optionA: "ui",
    optionB: "i",
    optionC: "ul",
    optionD: "em",
    correctOption: "optionC",
  },

  {
    question: "Which of the following characters indicate closing of a tag? ",
    optionA: "dot",
    optionB: "double slash",
    optionC: "double dot",
    optionD: "slash",
    correctOption: "optionD",
  },

  {
    question: "What is the font-size of the h1 heading tag?",
    optionA: "2 em",
    optionB: "5 em",
    optionC: "1.5 em",
    optionD: "3 em",
    correctOption: "optionA",
  },

  {
    question: "How many attributes are there in HTML5?",
    optionA: "one",
    optionB: "Four",
    optionC: "None of these",
    optionD: "Two",
    correctOption: "optionC",
  },

  {
    question: "How many heading tags are there in HTML5?",
    optionA: "6",
    optionB: "8",
    optionC: "12",
    optionD: "9",
    correctOption: "optionA",
  },

  {
    question: "Which of these numbers is an odd number ?",
    optionA: "Ten",
    optionB: "Twelve",
    optionC: "Eight",
    optionD: "Eleven",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following attributes is used to add link to any element?",
    optionA: "ref",
    optionB: "link",
    optionC: "new ref",
    optionD: "href",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "i",
    optionB: "italic",
    optionC: "style='i'",
    optionD: "style='italic'",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "/br",
    optionB: "br",
    optionC: "break",
    optionD: "/break",
    correctOption: "optionB",
  },
  {
    question: "What does HTML stand for?",
    optionA: "Hypertext Machine language.",
    optionB: "Hypertext and links markup language.",
    optionC: "Hypertext Markup Language.",
    optionD: "Hightext machine language.",
    correctOption: "optionC",
  },

  {
    question: "How is document type initialized in HTML5.?",
    optionA: "/DOCTYPE HTML",
    optionB: "/DOCTYPE",
    optionC: "!DOCTYPE HTML",
    optionD: "/DOCTYPE html",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following HTML Elements is used for making any text bold ?",
    optionA: "p",
    optionB: "i",
    optionC: "li",
    optionD: "b",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following HTML element is used for creating an unordered list?",
    optionA: "ui",
    optionB: "i",
    optionC: "ul",
    optionD: "em",
    correctOption: "optionC",
  },

  {
    question: "Which of the following characters indicate closing of a tag? ",
    optionA: "dot",
    optionB: "double slash",
    optionC: "double dot",
    optionD: "slash",
    correctOption: "optionD",
  },

  {
    question: "What is the font-size of the h1 heading tag?",
    optionA: "2 em",
    optionB: "5 em",
    optionC: "1.5 em",
    optionD: "3 em",
    correctOption: "optionA",
  },

  {
    question: "How many attributes are there in HTML5?",
    optionA: "one",
    optionB: "Four",
    optionC: "None of these",
    optionD: "Two",
    correctOption: "optionC",
  },

  {
    question: "How many heading tags are there in HTML5?",
    optionA: "6",
    optionB: "8",
    optionC: "12",
    optionD: "9",
    correctOption: "optionA",
  },

  {
    question: "Which of these numbers is an odd number ?",
    optionA: "Ten",
    optionB: "Twelve",
    optionC: "Eight",
    optionD: "Eleven",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following attributes is used to add link to any element?",
    optionA: "ref",
    optionB: "link",
    optionC: "new ref",
    optionD: "href",
    correctOption: "optionD",
  },

  {
    question: "What is the purpose of using div tags in HTML?",
    optionA: "For creating different style",
    optionB: "For adding heading",
    optionC: "For creating different section",
    optionD: "For adding title",
    correctOption: "optionC",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "i",
    optionB: "italic",
    optionC: "style='i'",
    optionD: "style='italic'",
    correctOption: "optionA",
  },

  {
    question:
      "Which of the following tags is used to make a portion of text italic in HTML?",
    optionA: "/br",
    optionB: "br",
    optionC: "break",
    optionD: "/break",
    correctOption: "optionB",
  },
];
