const questions = [
  {
    question: "What is JavaScript?",
    optionA:
      "JavaScript is an assembly language used to make the website interactive",
    optionB:
      "JS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC:
      " JavaScript is a scripting language used to make the website interactive",
    optionD:
      "JavaScript is a compiled language used to make the website interactive",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is correct about JavaScript?",
    optionA: " JavaScript is Assembly-language",
    optionB: " JavaScript is an Object-Oriented language",
    optionC: "JavaScript is an Object-Based language",
    optionD: "JavaScript is a High-level language",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not javascript data types?",
    optionA: "null",
    optionB: "number",
    optionC: "undefined",
    optionD: "All",
    correctOption: "optionD",
  },

  {
    question:
      " Which of the following can be used to call a JavaScript Code Snippet?",
    optionA: " Preprocessor",
    optionB: "RMI",
    optionC: "Function and methods",
    optionD: "Triggering event",
    correctOption: "optionC",
  },

  {
    question: " Which of the following scoping type does JavaScript use? ",
    optionA: "segmental",
    optionB: "sequential",
    optionC: "Literal",
    optionD: "Lexical",
    correctOption: "optionD",
  },

  {
    question: "Why JavaScript Engine is needed?",
    optionA: "Interpreting the JavaScript",
    optionB: "Both Compiling & Interpreting the JavaScript",
    optionC: " Compiling the JavaScript",
    optionD: "Parsing the javascript",
    correctOption: "optionA",
  },

  {
    question: "Which of the following is not a framework?",
    optionA: "cocoa js",
    optionB: "node js",
    optionC: "javascript",
    optionD: "jquery",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not an error in JavaScript?",
    optionA: "division by zero",
    optionB: " Missing of Bracket",
    optionC: "syntax error",
    optionD: "Missing of semicolons",
    correctOption: "optionA",
  },

  {
    question:
      "When interpreter encounters an empty statements, what it will do:",

    optionA: "Throws an error",
    optionB: "Prompts to complete the statement	",
    optionC: "Shows a warning",
    optionD: "Ignores the statements",
    correctOption: "optionD",
  },

  {
    question: "Which of the following type of a variable is volatile?",
    optionA: "Immutable variable",
    optionB: "Volatile variable",
    optionC: "Dynamic variable",
    optionD: "mututable variable",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following function of the String object returns the character in the string starting at the specified position via the specified number of characters?",
    optionA: "size",
    optionB: "search",
    optionC: "substr",
    optionD: "split",
    correctOption: "optionC",
  },

  {
    question:
      " In JavaScript, what will be used for calling the function definition expression:",
    optionA: "literal",
    optionB: "declaration",
    optionC: "calling",
    optionD: "prototype",
    correctOption: "optionA",
  },

  {
    question:
      "Which one of the following operator is used to check weather a specific property exists or not:",
    optionA: "exists",
    optionB: "in",
    optionC: "within",
    optionD: "Exists",
    correctOption: "optionB",
  },
  {
    question: "What is JavaScript?",
    optionA:
      "JavaScript is an assembly language used to make the website interactive",
    optionB:
      "JS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC:
      " JavaScript is a scripting language used to make the website interactive",
    optionD:
      "JavaScript is a compiled language used to make the website interactive",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is correct about JavaScript?",
    optionA: " JavaScript is Assembly-language",
    optionB: " JavaScript is an Object-Oriented language",
    optionC: "JavaScript is an Object-Based language",
    optionD: "JavaScript is a High-level language",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not javascript data types?",
    optionA: "null",
    optionB: "number",
    optionC: "undefined",
    optionD: "All",
    correctOption: "optionD",
  },

  {
    question:
      " Which of the following can be used to call a JavaScript Code Snippet?",
    optionA: " Preprocessor",
    optionB: "RMI",
    optionC: "Function and methods",
    optionD: "Triggering event",
    correctOption: "optionC",
  },

  {
    question: " Which of the following scoping type does JavaScript use? ",
    optionA: "segmental",
    optionB: "sequential",
    optionC: "Literal",
    optionD: "Lexical",
    correctOption: "optionD",
  },

  {
    question: "Why JavaScript Engine is needed?",
    optionA: "Interpreting the JavaScript",
    optionB: "Both Compiling & Interpreting the JavaScript",
    optionC: " Compiling the JavaScript",
    optionD: "Parsing the javascript",
    correctOption: "optionA",
  },

  {
    question: "Which of the following is not a framework?",
    optionA: "cocoa js",
    optionB: "node js",
    optionC: "javascript",
    optionD: "jquery",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not an error in JavaScript?",
    optionA: "division by zero",
    optionB: " Missing of Bracket",
    optionC: "syntax error",
    optionD: "Missing of semicolons",
    correctOption: "optionA",
  },

  {
    question:
      "When interpreter encounters an empty statements, what it will do:",

    optionA: "Throws an error",
    optionB: "Prompts to complete the statement	",
    optionC: "Shows a warning",
    optionD: "Ignores the statements",
    correctOption: "optionD",
  },

  {
    question: "Which of the following type of a variable is volatile?",
    optionA: "Immutable variable",
    optionB: "Volatile variable",
    optionC: "Dynamic variable",
    optionD: "mututable variable",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following function of the String object returns the character in the string starting at the specified position via the specified number of characters?",
    optionA: "size",
    optionB: "search",
    optionC: "substr",
    optionD: "split",
    correctOption: "optionC",
  },

  {
    question:
      " In JavaScript, what will be used for calling the function definition expression:",
    optionA: "literal",
    optionB: "declaration",
    optionC: "calling",
    optionD: "prototype",
    correctOption: "optionA",
  },

  {
    question:
      "Which one of the following operator is used to check weather a specific property exists or not:",
    optionA: "exists",
    optionB: "in",
    optionC: "within",
    optionD: "Exists",
    correctOption: "optionB",
  },
  {
    question: "What is JavaScript?",
    optionA:
      "JavaScript is an assembly language used to make the website interactive",
    optionB:
      "JS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC:
      " JavaScript is a scripting language used to make the website interactive",
    optionD:
      "JavaScript is a compiled language used to make the website interactive",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is correct about JavaScript?",
    optionA: " JavaScript is Assembly-language",
    optionB: " JavaScript is an Object-Oriented language",
    optionC: "JavaScript is an Object-Based language",
    optionD: "JavaScript is a High-level language",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not javascript data types?",
    optionA: "null",
    optionB: "number",
    optionC: "undefined",
    optionD: "All",
    correctOption: "optionD",
  },

  {
    question:
      " Which of the following can be used to call a JavaScript Code Snippet?",
    optionA: " Preprocessor",
    optionB: "RMI",
    optionC: "Function and methods",
    optionD: "Triggering event",
    correctOption: "optionC",
  },

  {
    question: " Which of the following scoping type does JavaScript use? ",
    optionA: "segmental",
    optionB: "sequential",
    optionC: "Literal",
    optionD: "Lexical",
    correctOption: "optionD",
  },

  {
    question: "Why JavaScript Engine is needed?",
    optionA: "Interpreting the JavaScript",
    optionB: "Both Compiling & Interpreting the JavaScript",
    optionC: " Compiling the JavaScript",
    optionD: "Parsing the javascript",
    correctOption: "optionA",
  },

  {
    question: "Which of the following is not a framework?",
    optionA: "cocoa js",
    optionB: "node js",
    optionC: "javascript",
    optionD: "jquery",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not an error in JavaScript?",
    optionA: "division by zero",
    optionB: " Missing of Bracket",
    optionC: "syntax error",
    optionD: "Missing of semicolons",
    correctOption: "optionA",
  },

  {
    question:
      "When interpreter encounters an empty statements, what it will do:",

    optionA: "Throws an error",
    optionB: "Prompts to complete the statement	",
    optionC: "Shows a warning",
    optionD: "Ignores the statements",
    correctOption: "optionD",
  },

  {
    question: "Which of the following type of a variable is volatile?",
    optionA: "Immutable variable",
    optionB: "Volatile variable",
    optionC: "Dynamic variable",
    optionD: "mututable variable",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following function of the String object returns the character in the string starting at the specified position via the specified number of characters?",
    optionA: "size",
    optionB: "search",
    optionC: "substr",
    optionD: "split",
    correctOption: "optionC",
  },

  {
    question:
      " In JavaScript, what will be used for calling the function definition expression:",
    optionA: "literal",
    optionB: "declaration",
    optionC: "calling",
    optionD: "prototype",
    correctOption: "optionA",
  },

  {
    question:
      "Which one of the following operator is used to check weather a specific property exists or not:",
    optionA: "exists",
    optionB: "in",
    optionC: "within",
    optionD: "Exists",
    correctOption: "optionB",
  },
  {
    question: "What is JavaScript?",
    optionA:
      "JavaScript is an assembly language used to make the website interactive",
    optionB:
      "JS is designed to separate the presentation and content, including layout, colors, and fonts.",
    optionC:
      " JavaScript is a scripting language used to make the website interactive",
    optionD:
      "JavaScript is a compiled language used to make the website interactive",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is correct about JavaScript?",
    optionA: " JavaScript is Assembly-language",
    optionB: " JavaScript is an Object-Oriented language",
    optionC: "JavaScript is an Object-Based language",
    optionD: "JavaScript is a High-level language",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not javascript data types?",
    optionA: "null",
    optionB: "number",
    optionC: "undefined",
    optionD: "All",
    correctOption: "optionD",
  },

  {
    question:
      " Which of the following can be used to call a JavaScript Code Snippet?",
    optionA: " Preprocessor",
    optionB: "RMI",
    optionC: "Function and methods",
    optionD: "Triggering event",
    correctOption: "optionC",
  },

  {
    question: " Which of the following scoping type does JavaScript use? ",
    optionA: "segmental",
    optionB: "sequential",
    optionC: "Literal",
    optionD: "Lexical",
    correctOption: "optionD",
  },

  {
    question: "Why JavaScript Engine is needed?",
    optionA: "Interpreting the JavaScript",
    optionB: "Both Compiling & Interpreting the JavaScript",
    optionC: " Compiling the JavaScript",
    optionD: "Parsing the javascript",
    correctOption: "optionA",
  },

  {
    question: "Which of the following is not a framework?",
    optionA: "cocoa js",
    optionB: "node js",
    optionC: "javascript",
    optionD: "jquery",
    correctOption: "optionC",
  },

  {
    question: "Which of the following is not an error in JavaScript?",
    optionA: "division by zero",
    optionB: " Missing of Bracket",
    optionC: "syntax error",
    optionD: "Missing of semicolons",
    correctOption: "optionA",
  },

  {
    question:
      "When interpreter encounters an empty statements, what it will do:",

    optionA: "Throws an error",
    optionB: "Prompts to complete the statement	",
    optionC: "Shows a warning",
    optionD: "Ignores the statements",
    correctOption: "optionD",
  },

  {
    question: "Which of the following type of a variable is volatile?",
    optionA: "Immutable variable",
    optionB: "Volatile variable",
    optionC: "Dynamic variable",
    optionD: "mututable variable",
    correctOption: "optionD",
  },

  {
    question:
      "Which of the following function of the String object returns the character in the string starting at the specified position via the specified number of characters?",
    optionA: "size",
    optionB: "search",
    optionC: "substr",
    optionD: "split",
    correctOption: "optionC",
  },

  {
    question:
      " In JavaScript, what will be used for calling the function definition expression:",
    optionA: "literal",
    optionB: "declaration",
    optionC: "calling",
    optionD: "prototype",
    correctOption: "optionA",
  },

  {
    question:
      "Which one of the following operator is used to check weather a specific property exists or not:",
    optionA: "exists",
    optionB: "in",
    optionC: "within",
    optionD: "Exists",
    correctOption: "optionB",
  },
];
